import  modules 
import streamlit as st


st.set_page_config(page_title="TPL", page_icon=None,layout="wide", initial_sidebar_state='auto',menu_items={
         'Get Help': 'https://torrent.katonic.ai/platform/workspace',
         'Report a bug': "https://torrent.katonic.ai/platform/workspace",
         'About': "# This is a header. This is an *extremely* cool app!"
     })


from modules.functions import img_to_bytes
from modules.utilities import cmplt_file_df,cmplt_hrchy,hrcrhy_file_df,child_file_df,model,top_features_rfe,label_encode,model,label_mapping
from modules.transformations import create_label,rename_columns

from modules.edacharts import chart_1,chart_2,chart_3,chart_4
from modules.single_complaint import single_complaint_chart
from modules.bulk_complaints import bulk_cmplnt_section
from modules.model_performance import model_performance_chart,feature_importance_chart
import copy


st.write("""
      <style>
            div.block-container{
                padding-top:0rem;
               
            }
          
    </style>        
""",unsafe_allow_html=True)
header_html = "<img src='data:image/png;base64,{}' class='img-fluid' height=200 width=200 style='float:right'>".format(img_to_bytes('tpl_logo.jpg')
)
st.markdown(
    header_html, unsafe_allow_html=True,
)





hide_streamlit_style = """
             <style>
             #MainMenu {visibility: hidden;}
             footer {visibility: hidden;}
             </style>
             """
st.markdown(hide_streamlit_style, unsafe_allow_html=True) 

st.sidebar.image('logo.png')
option = st.sidebar.radio("",("About App","Model Performance","Single Complaint", "Bulk Complaints","Exploratory Data Analysis", ))

parent_cmplt = copy.deepcopy(cmplt_file_df)
parent_cmplt.columns = rename_columns(parent_cmplt,prefix='parent_')


        
if option == "Exploratory Data Analysis":
    st.header("Exploratory Data Analysis")
    col1, col2,col3,col4,col5 = st.columns(5)
    with col1:
        value = len(parent_cmplt['parent_business_partner'].unique())
        st.write("Total BP that raised complaints")
        st.write("\n")
        st.write("\n")
        st.write("**"+str(value)+"**")

    with col2:
        value = len(parent_cmplt['parent_complaint_number'].unique())
        st.write("Total Complaints till date")
        st.write("\n")
        st.write("\n")
        st.write("**"+str(value)+"**")

    with col3:
        value = parent_cmplt['parent_restoration_duration'].mean()
        st.write("Average Restoration Duration(mins)")
        st.write("**"+str(value)+"**")

    with col4:
      
        parent_cmplt['flg'] = create_label(parent_cmplt,hrcrhy_file_df)
        parent_cmplt_temp = parent_cmplt[parent_cmplt['flg']!='not_in_hierarchy']
        value = parent_cmplt_temp['flg'].value_counts().index[0]
        st.write("Most Affected Functional Location Group")
        st.write("**"+str(value)+"**")


    st.markdown("""---""") 

    
    col1, col2 = st.columns(2)

    with col1:
        chart_1(cmplt_file_df)

    with col2:
        chart_2(cmplt_file_df)

    chart_3(parent_cmplt_temp)
    chart_4(cmplt_file_df)

elif option=="About App":
    st.header("About the Application")
    st.write("This app will help you perform prediction whenever there are any complaints reported. One can also analyse the performance of the model once the actual affected functional location group is available.")
    st.write("We received 3 types of files containing parent complaints, heirarchy information of BP and child complaints.")
    st.write("**Problem Statement**: We are trying to dynamically update our estimation of the FLG(functional location group) whenever there is a arrival of new child complaint around the same FSP circuit.")
    st.write("**Scope**: Biggest contributor to total time to resolution of a complaint is the identification of the Fault Location in the Network hierarchy. We built a digital twin simulating the evolution of network topology health metrics where direct measurement of network health was unavailable, we defined smart proxies.")
    st.write("This app consist of four sections:")
    st.markdown("- **Model Performance** : When the actual affected functional location group is available then we can pass the parent complaint and child complaint files to check the accuracy of the model.")
    st.markdown("- **Single Complaint** : One can use this section whereever there are bulk complaints from single fsp_circuit only.")
    st.markdown("- **Bulk Complaint** : One can use this whenever there are bulk complaints from several fsp_circuit.") 
    st.markdown("- **Exploratory Data Analysis** : This provides the statistics about complaints graphically.")
    st.subheader("About Experimentation")
    st.write("The experimentation started with data analysis,data visualization, data cleaning, removing unnecessary records ,treating missing values, removing outliers, splitting the data into train, validation and test.")   
    st.write("Encoding techniques were applied to convert categorical features, calculated some features to capture past information, applied feature elimination and selection inorder to pass best possible features to models.")
    st.write("We passed the features set on different models :logistic regression,random forest, lightgbm, catboost,xgboost,etc")
    st.write("Model evaluation was based on different classification metrics. The best model that got selected was **Random Forest classifier**.")
    st.write("**Assumptions**: This application works only when there is atleast one child complaint reported against a parent complaint.")
    #st.write("**Business Outcome** : 25% reduction in time taken to identify the root cause (FLG) that resulted in a consumer complaint")
    st.write("**Future Scope** : Right now our model performance is around 50% which can be surely improved if we get more information regarding the current network or asset health metrics.Focus would also be to reduce the deviation of validation and heldout set accuracy. We would try to build an algorithm that will help you optimise the time savings if we have accurate time measures.")
    st.write("**Business Outcome**:")
    st.write("For a given complaint, considering time difference between attending and allocation duration, suppose 25% of time is required to reach BP. Out of remaining 75% considering 37.5 % of time required to resolve the issue remaing 37.5% of time that is used to debug where the issue could be, is where our model will help you save time.")
    st.write("For a given day, i.e 12-07-2021, wherein we had 88 parent complaints (when parent has more than 2 complaints). Based on the assumptions, considering 37.5% of sum of time difference between attending and allocation duration (in minutes), so on an average we save **{} minutes per complaint** when accuracy of model is 100%.".format(14.55))
    st.write("As per current model performace (50%), time saved would be: **{} minutes per complaint** ".format(7.385))
elif option == "Model Performance":
    
    print("called feature importance function")
    feature_importance_chart(cmplt_file_df,hrcrhy_file_df,child_file_df,model,top_features_rfe)
    
    st.header("Measuring the performance of uploaded data")
    
    model_performance_chart(cmplt_hrchy,hrcrhy_file_df,model,label_encode,top_features_rfe)
    
elif option == "Single Complaint":
    single_complaint_chart(cmplt_hrchy,cmplt_file_df,hrcrhy_file_df,model,label_encode,top_features_rfe)
           
elif option == "Bulk Complaints":
    st.header("Bulk Complaints (multiple parent and child)")
    st.subheader("Sample Data records to pass for prediction")

    bulk_cmplnt_section(cmplt_file_df,child_file_df,cmplt_hrchy,hrcrhy_file_df,label_encode,model,label_mapping,top_features_rfe)
    
else:
    st.error("Something has gone terribly wrong.")


