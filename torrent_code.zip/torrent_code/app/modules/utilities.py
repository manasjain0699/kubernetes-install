import joblib
import pandas as pd
import streamlit as st
import copy
import dill
#-----------------variables---------------------------------------


@st.cache()
def readcsv(path):
    return pd.read_csv(path) 

parent_columns = ['parent_reg_date', 'parent_reg__time', 'parent_complaint_number','parent_business_partner', 'parent_msp_circuit',
       'parent_msp_circuit_description', 'parent_final_obs__code_group','parent_final_obs__code', 'parent_mru', 'parent_industry',
       'parent_industry_system', 'parent_affected_bp','parent_restoration_duration', 'parent_mode', 'parent_regi__group',
       'parent_regi__code', 'parent_rate_category', 'parent_bp_classification','parent_account_class', 'parent_location', 'parent_sub_station',
       'parent_area', 'parent_responsible_zone', 'parent_responsible_dept','parent_zone', 'parent_fsp_circuit', 'parent_fsp_circuit_description',
       'parent_affected_func__location']


label_mapping = {'11kv_oh_feeder_cb':0,'11kv_ug_feeder_cb':1, '22_kv_feeder':2, '22_kv_sub_feeder':3,'ht_customer_ss':4, 
 'dist__sub_station':5,'dist_transformer':6, 'fsp':7,'fsp_circuit':8,'fsp_sub_circuit':9, 'dfsp':10, 'dfsp_circuit':11,
 'dfsp_sub_circuit':12, 'msp':13,'msp_circuit':14,'otdp':15,'ottp':16, 'lt_sw_fuse_unit':17,'delivery_point':18, 'bbc_ahd_':19,
 'dist__box':20, 'device_location':21}

lb_key_list = {v:k for k,v in label_mapping.items()} 

hierarchy_cols = ['hrcrhy_11kv_oh_feeder_cb','hrcrhy_11kv_ug_feeder_cb','hrcrhy_22_kv_feeder','hrcrhy_22_kv_sub_feeder',
                  'hrcrhy_ht_customer_ss','hrcrhy_dist__sub_station','hrcrhy_dist_transformer','hrcrhy_fsp',
                  'hrcrhy_fsp_circuit','hrcrhy_fsp_sub_circuit','hrcrhy_dfsp','hrcrhy_dfsp_circuit','hrcrhy_dfsp_sub_circuit',
                  'hrcrhy_msp','hrcrhy_msp_circuit','hrcrhy_otdp','hrcrhy_ottp','hrcrhy_lt_sw_fuse_unit',
                  'hrcrhy_delivery_point','hrcrhy_bbc_ahd_','hrcrhy_dist__box','hrcrhy_device_location'] 

pd.DataFrame(columns=parent_columns[:10]).to_csv("saved_state_of_parent_with_child.csv",index=False)

base_dir = "/home/katonic/workspace/torrent_app/katonic/kfs_private/"

explainer =""
with open(base_dir+'lime_explainer.pkl','rb') as f:
    explainer = dill.load(f)
    
##--------------read files-----------------------------------------------
cmplt_file_df =         readcsv(base_dir+"parent_all_columns.csv")
print("read parent cmplt file successfully")

hrcrhy_file_df =        readcsv(base_dir+"bp_hierarchy_file.csv",)
print("read hierachy file successfully")

child_file_df =         readcsv(base_dir+"only_child_cmplt_file.csv",)
print("read child file successfully")

cmplt_hrchy =           pd.read_csv(base_dir+"cmplt_hrchy_file.csv",)


model =                 joblib.load(base_dir+"best_model.joblib")

label_encode =          joblib.load(base_dir+"label_encode.joblib")

hierachy_label_encode = joblib.load(base_dir+"hrcrhy_label_encode.joblib")

top_features_rfe=       joblib.load(base_dir+"selected_feature_list.joblib")

feat_dict_original =    joblib.load(base_dir+'feature_meta_dict.joblib')                

feat_dict = copy.deepcopy(feat_dict_original)