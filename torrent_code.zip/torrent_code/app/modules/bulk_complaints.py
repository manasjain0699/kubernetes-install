import datetime
from functools import reduce
from pkg_resources import normalize_path
import streamlit as st
import pandas as pd
import altair as alt
import os
from PIL import Image
import matplotlib.pyplot as plt
import joblib
import streamlit.components.v1 as components
from sklearn.metrics import confusion_matrix,classification_report
import numpy as np
import seaborn as sns
import pickle
import dill
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,precision_score,f1_score
import seaborn as sns
import numpy as np
import shap
import datetime as dt
import streamlit.components.v1 as components
from .functions import eval_metrics,performance_matices,convert_df,predict,hierarchy_asset_affected,img_to_bytes,st_shap,mergefiles,create_bulk_cmplt_df,no_of_times_comlpt_for_bulk_customer
from .transformations import *
from .utilities import *
import datetime




    

def bulk_cmplnt_section(cmplt_file_df,child_file_df,cmplt_hrchy,hrcrhy_file_df,label_encode,model,label_mapping,top_features_rfe):

    sample_cmplt_df = cmplt_file_df.head(1000).copy()
      
    sample_child_df = child_file_df.head(1000).copy()

    
    st.write("**Sample complaint input file structure**")
    st.write(sample_cmplt_df.head())
    csv = convert_df(sample_cmplt_df.head(1000))
    st.download_button("DownloadSample",csv,"sample_parent_cmplt.csv","text/csv",key='download-csv')


    st.write("**Sample child complaint input file structure**")
    st.write(sample_child_df.head())
    csv = convert_df(sample_child_df.head(1000))
    st.download_button("DownloadSample",csv,"sample_child_cmplt.csv","text/csv",key='download-csv')

    col1, col2 = st.columns(2)

    with col1:
        cmplt_file_upload = st.file_uploader("Upload parent complaint csv file for predictions (file structure should be exactly like the sample file)", type=["csv"])

    with col2:
        child_file_upload = st.file_uploader("Upload child complaint csv file for predictions (file structure should be exactly like the sample file)", type=["csv"])

    
    if cmplt_file_upload is None:
        st.error("Please upload parent complaint file")
   
    elif  child_file_upload is None:
        st.error("Please upload child complaint file")     

    elif cmplt_file_upload and child_file_upload :
        
        up_prnt_hrchy_child =  create_bulk_cmplt_df(cmplt_file_upload,child_file_upload,hrcrhy_file_df)
        
        predictions = model.predict(up_prnt_hrchy_child[top_features_rfe].fillna(-1))
        batch_df_unencode = up_prnt_hrchy_child[['parent_business_partner','parent_complaint_number','child_partner_no']+top_features_rfe]
        
        batch_df_unencode['flg_pred'] = predictions
        batch_df_unencode['flg_pred_desciption'] = batch_df_unencode['flg_pred'].map(lb_key_list)
        st.header("Prediction Results for Multiple parent child complaints")
        st.write(batch_df_unencode)
        csv = convert_df(batch_df_unencode)
        st.download_button("Download the Result",csv,"results.csv","text/csv",key='download-csv')