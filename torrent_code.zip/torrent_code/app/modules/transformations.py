import category_encoders as ce
import joblib
from sklearn.feature_selection import mutual_info_classif
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import RFE
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,f1_score,precision_score
import seaborn as sns

label_mapping_dist = {'11kv_oh_feeder_cb':0,
 '11kv_ug_feeder_cb':1, 
 '22_kv_feeder':2, 
 '22_kv_sub_feeder':3,
 'ht_customer_ss':4, 
 'dist__sub_station':5, 
 'dist_transformer':6, 
 'fsp':7,
 'fsp_circuit':8,
 'fsp_sub_circuit':9, 
 'dfsp':10, 
 'dfsp_circuit':11,
 'dfsp_sub_circuit':12, 
 'msp':13,
  'msp_circuit':14,
 'otdp':15, 
 'ottp':16, 
 'lt_sw_fuse_unit':17, 
 'delivery_point':18, 
 'bbc_ahd_':19,
 'dist__box':20, 
 'device_location':21}

feature_meta_dict = {}
def feature_creation_dict(df,base_feature,generated_feature) :
    df.sort_values('parent_reg_date_time',inplace=True)
    feature_meta_dict.update(pd.DataFrame(
        df.groupby(base_feature).tail(1)).set_index(base_feature)[[generated_feature]].to_dict())


def rename_columns(df,prefix="",suffix=""):
    df.columns = df.columns.str.strip()
    df.columns = df.columns.str.lower()
    df.columns = df.columns.str.replace("\n","_")
    df.columns = df.columns.str.replace("[ ,.,%,&,/,-,(,),]","_")
    df.columns = prefix+ df.columns 
    df.columns = df.columns + suffix
    return df.columns


############################### Label ################################
def create_label(df,hierarchy_df):
    df['flg'] = "not_in_hierarchy"
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_11kv_oh_feeder_cb'].unique()),'11kv_oh_feeder_cb',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_11kv_ug_feeder_cb'].unique()),'11kv_ug_feeder_cb',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_22_kv_feeder'].unique()),'22_kv_feeder',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_22_kv_sub_feeder'].unique()),'22_kv_sub_feeder',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_ht_customer_ss'].unique()),'ht_customer_ss',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dist__sub_station'].unique()),'dist__sub_station',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dist_transformer'].unique()),'dist_transformer',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_fsp'].unique()),'fsp',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_fsp_circuit'].unique()),'fsp_circuit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_fsp_sub_circuit'].unique()),'fsp_sub_circuit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dfsp'].unique()),'dfsp',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dfsp_circuit'].unique()),'dfsp_circuit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dfsp_sub_circuit'].unique()),'dfsp_sub_circuit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_msp'].unique()),'msp',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_msp_circuit'].unique()),'msp_circuit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_otdp'].unique()),'otdp',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_ottp'].unique()),'ottp',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_lt_sw_fuse_unit'].unique()),'lt_sw_fuse_unit',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_delivery_point'].unique()),'delivery_point',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_bbc_ahd_'].unique()),'bbc_ahd_',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_dist__box'].unique()),'dist__box',df['flg'])
    df['flg'] = np.where(df['parent_affected_func__location'].isin(hierarchy_df['hrcrhy_device_location'].unique()),'device_location',df['flg'])
    
    return df['flg']

def label_mapping(df):
    return df['flg'].map(label_mapping_dist)

##################### Filling Missing Values #########################################

def fill_parent_reg__time(df):
    df['parent_reg__time'] = np.where(df['parent_reg__time']=='#','00:00:00',df['parent_reg__time'])
    return df['parent_reg__time'].fillna('00:00:00')

def fill_parent_rate_category(df):
    df['parent_rate_category'] = df['parent_rate_category'].fillna('Non Consumer')
    df['parent_rate_category'] = df['parent_rate_category'].apply(lambda x: "_".join(x.lower().split()))
    return df['parent_rate_category']

def fill_parent_area(df):
    return df['parent_area'].fillna('IN/Not assigned')

def fill_parent_mru(df):
    return df['parent_mru'].fillna('Not assigned')

def fill_child_mru(df):
    return df['child_mru'].fillna('Not assigned')

def fill_child_location(df):
    return df['child_location'].fillna('Not assigned')
############################# Data Formatting ################################
def format_parent_reg_date(df):
    df['parent_reg_date_time'] = df['parent_reg_date'] + " " + df['parent_reg__time']
    df['parent_reg_date_time'] = pd.to_datetime(df['parent_reg_date_time'],format="%d-%m-%Y %H:%M:%S") 
    return df['parent_reg_date_time']

def format_child_reg_date(df):

    def convert_child_date_time(x):
        x=x-25569
        x=x*86400
        x=datetime.fromtimestamp(x).strftime('%Y-%m-%d %H:%M:%S')
        return x
    
    df['child_reg_date_time'] = df['child_registration_date']+df['child_registration_time']
    df['child_reg_date_time'] = df['child_reg_date_time'].apply(convert_child_date_time)
    
    return pd.to_datetime(df['child_reg_date_time'],format="%Y-%m-%d %H:%M:%S")

################################ Fetaure Creation ######################################
def date_time_features(df,column_name):
    df[column_name+"_day"] = df[column_name].dt.day
    df[column_name+"_month"] = df[column_name].dt.month
    df[column_name+"_year"] = df[column_name].dt.year
    df[column_name+"_week"] = df[column_name].dt.week
    df[column_name+"_dayofweek"] = df[column_name].dt.dayofweek
    df[column_name+"_quarter"] = df[column_name].dt.quarter
    df[column_name+"_hour"] = df[column_name].dt.hour
    df[column_name+"_minute"] = df[column_name].dt.minute
    df[column_name+"_periodofday"] = (df[column_name].dt.hour % 24 + 4) // 4
    
    return df

def no_of_times_asset_affected(df):
    df['no_of_times_asset_affected'] = 1
    df.sort_values(by=['parent_reg_date_time'],inplace=True)
    df['no_of_times_asset_affected'] = df.groupby(['parent_affected_func__location'])['no_of_times_asset_affected'].apply(lambda x: x.cumsum().shift(1))
    df['no_of_times_asset_affected'].fillna(0,inplace=True)
    
    return df['no_of_times_asset_affected']

def days_when_asset_last_affected(df):
    df.sort_values(by=['parent_reg_date_time'],inplace=True)
    df['days_when_asset_last_affected'] = df.groupby(['parent_affected_func__location'])['parent_reg_date_time'].apply(lambda x:x-x.shift(1))
    df['days_when_asset_last_affected'] = df['days_when_asset_last_affected'].fillna(pd.Timedelta(days=0)).dt.days
    
    return df['days_when_asset_last_affected']

def hierarchy_asset_affected(temp_cmp, column_name):
    new_column = column_name+"_noof_times_affected_in_past"
    temp_join = pd.merge(temp_cmp[['parent_reg_date_time','parent_complaint_number',column_name]],temp_cmp,how='left',
                         left_on=column_name,right_on='parent_affected_func__location')[['parent_reg_date_time_x','parent_complaint_number_x',column_name+"_x",'parent_reg_date_time_y',
                                                                                      column_name+'_y','parent_affected_func__location']]
    temp_join[new_column] = 1
    temp_reduce = temp_join[temp_join['parent_reg_date_time_x']>temp_join['parent_reg_date_time_y']].groupby(['parent_reg_date_time_x',column_name+"_x"])[new_column].sum()
    
    temp_cmp_df = pd.merge(temp_cmp,temp_reduce,how='left',left_on=['parent_reg_date_time',column_name],right_on=['parent_reg_date_time_x',column_name+'_x'])
    
    temp_cmp_df[new_column] = np.where(temp_cmp_df[column_name]=="not-connected",-1,temp_cmp_df[new_column])
    temp_cmp_df[new_column] = temp_cmp_df[new_column].fillna(-1)
    temp_cmp_df=temp_cmp_df[temp_cmp.columns.tolist()+[new_column]]
    
    return temp_cmp_df


def noof_days_before_asset_affected(temp_cmp, column_name):
    new_column = column_name+"_noof_days_before_affected_in_past"
    temp_join = pd.merge(temp_cmp[['parent_reg_date_time','parent_complaint_number',column_name]],temp_cmp,how='left',
                         left_on=column_name,right_on='parent_affected_func__location')[['parent_reg_date_time_x','parent_complaint_number_x',column_name+"_x",'parent_reg_date_time_y',
                                                                                     column_name+'_y','parent_affected_func__location']]
    temp_join[new_column] = 0
    temp_reduce = temp_join[temp_join['parent_reg_date_time_x']>temp_join['parent_reg_date_time_y']]
    temp_reduce.sort_values(by=['parent_reg_date_time_x','parent_reg_date_time_y'],inplace=True)
    temp_reduce= temp_reduce[['parent_reg_date_time_x','parent_reg_date_time_y','parent_complaint_number_x',column_name+"_x",new_column]]
    temp_reduce = temp_reduce.groupby(['parent_reg_date_time_x',column_name+"_x"]).apply(lambda x: x.iloc[-1]).reset_index(drop=True)
    temp_reduce[new_column] = temp_reduce['parent_reg_date_time_x']-temp_reduce['parent_reg_date_time_y']
    temp_reduce[new_column] = temp_reduce[new_column].dt.total_seconds() / (24*60*60)#.apply(lambda x: float(x.seconds))
    
    temp_cmp_df = pd.merge(temp_cmp,temp_reduce,how='left',left_on=['parent_reg_date_time',column_name],right_on=['parent_reg_date_time_x',column_name+'_x'])
    temp_cmp_df[new_column] = np.where(temp_cmp_df[column_name]=="not-connected",-1.0,temp_cmp_df[new_column])
    temp_cmp_df[new_column] = temp_cmp_df[new_column].fillna(0.0)#(pd.Timedelta(seconds=0))
    temp_cmp_df=temp_cmp_df[temp_cmp.columns.tolist()+[new_column]]
    
    return temp_cmp_df


def is_parent_ht_customer(df):
    df['is_parent_ht_customer'] = np.where(df['hrcrhy_ht_customer_ss']=='not-connected',0,1)
    return df['is_parent_ht_customer']

def average_affected_bp(df):
    df.sort_values(by=['parent_reg_date_time'],inplace=True)
    return df.groupby(['parent_business_partner'])['parent_affected_bp'].apply(lambda x: x.expanding().mean().shift(1)).fillna(0)

def median_affected_bp_past(df):
    df.sort_values(by=['parent_reg_date_time'],inplace=True)
    return df.groupby(['parent_business_partner'])['parent_affected_bp'].apply(lambda x: x.expanding().median().shift(1)).fillna(0)

def no_of_times_comlpt_raised_for_asset(df,col_name):
    df.sort_values('parent_reg_date_time',inplace=True)
    return df.groupby(col_name)[col_name].cumcount()

def no_of_complaints_for_bp_past(df):
    df['no_of_complaints_for_bp_past'] = 1
    df.sort_values(by=['child_reg_date_time'],inplace=True)
    return df.groupby(['child_partner_no'])['no_of_complaints_for_bp_past'].apply(lambda x: x.cumsum().shift(1)).fillna(0)

def time_diff_btwn_child_parent_cmplt(df):
    df['time_diff_btwn_child_parent_cmplt_mins']  = pd.to_datetime(df['child_reg_date_time'])-pd.to_datetime(df['parent_reg_date_time'])
    return df['time_diff_btwn_child_parent_cmplt_mins'].apply(lambda x: x.seconds/60)

def no_of_past_child_cmplt(df):
    df['no_of_past_child_cmplt'] = 1
    df.sort_values(by=['parent_reg_date_time','child_reg_date_time'],inplace=True)
    return df.groupby(['parent_complaint_number'])['no_of_past_child_cmplt'].apply(lambda x: x.cumsum()).fillna(0)

def child_vip_flag(df):
    return np.where(df['child_vip_flag']=='X',1,0)

############################# Data Transformation ############################################

def label_encoding_fit(df, label_encode_list,file_name):
    label_encode = ce.OrdinalEncoder(cols=label_encode_list)
    label_encode.fit(df)
    joblib.dump(label_encode,file_name)
    
def label_encoding_transfrom(df,file_name):
    label_encode = joblib.load(file_name)
    return label_encode.transform(df)


################################### Feature Selection #####################################

def univarient_selection(df):
    return [x for x in df.columns if df[x].std()>0]

def correlation_feature_elemination(train_data, corr_factor):
    corr = train_data.corr()
    columns = np.full((corr.shape[0],), True,dtype=bool)
    for i in range(corr.shape[0]) :
        for j in range(i+1, corr.shape[0]):
            if corr.iloc[i,j] >= corr_factor:
                if columns[j]:
                    columns[j] = False

    sel_cols = train_data.columns[columns]
    return sel_cols

def mutual_info_score(X_train,y_train):
    da = pd.DataFrame()
    da['column_name'] = X_train.columns.tolist()
    da['score'] = mutual_info_classif(X_train,y_train,random_state=12)
    top_features = da.sort_values('score',ascending=False).reset_index(drop=True).loc[0:20,'column_name'].tolist()
    return top_features

def recursive_feature_engineering(X_train, y_train):
    selector = RFE(DecisionTreeClassifier(), n_features_to_select=20, step=1)
    selector = selector.fit(X_train, y_train)

    feature_imp = {"Column_names":list(X_train.columns),"Importance":selector.ranking_.tolist()}

    top_features_rfe = pd.DataFrame(feature_imp)[selector.support_]
    return top_features_rfe.sort_values("Importance",ascending=False)['Column_names'].tolist()
    
    
####################################### Model Performance ###########################################

def performance_matices(model, X, y, order_hierarchy) :

    y_pred = model.predict(X)
    
    print("Accuracy Score :", accuracy_score(y,y_pred))
    # print("ROC AUC Score :", roc_auc_score(y_train,best_model.predict_proba(X_train),multi_class='ovr'))
    print("recall: ",recall_score(y,y_pred,average='weighted'))
    print("f1_scr: ",f1_score(y,y_pred,average='weighted'))
    print("precision_score: ",precision_score(y,y_pred,average='weighted'))
    
    print('\033[1mClassification Report \033[0m')
    print(classification_report(y,y_pred,labels=order_hierarchy))

    print('\033[1mConfusion_Matrix\033[0m')
    confusion_matrix_print = confusion_matrix(y, y_pred,labels=order_hierarchy)
    res1=[0,1]
    res2=[0,1]
    group_counts = ["{0:0.0f}".format(value) for value in confusion_matrix_print.flatten()]
    group_percentages = ['{0:.2%}'.format(value) for value in confusion_matrix_print.flatten()/np.sum(confusion_matrix_print)]
    labels = [f"{v1}\n{v2}" for v1, v2 in zip(group_percentages,group_counts)]
    labels = np.asarray(labels).reshape(len(y.unique()),len(y.unique()))
# 
    fig, ax = plt.subplots(figsize=(20,20))
    sns.heatmap(confusion_matrix_print, annot=labels, fmt='', cmap='Blues',robust=True,
    annot_kws={'fontsize':'large','fontweight':'bold'}
    ,cbar=False,xticklabels=['Predicted dist__sub_station','Predicted dist_transformer','Predicted fsp','Predicted fsp_circuit','Predicted fsp_sub_circuit',
                             'Predicted dfsp','Predicted dfsp_circuit','Predicted dfsp_sub_circuit','Predicted msp','Predicted msp_circuit','Predicted ottp',
                             'Predicted lt_sw_fuse_unit','Predicted delivery_point','Predicted bbc_ahd_','Predicted dist__box']
    ,yticklabels=['Actual dist__sub_station','Actual dist_transformer','Actual fsp','Actual fsp_circuit','Actual fsp_sub_circuit','Actual dfsp',
                  'Actual dfsp_circuit','Actual dfsp_sub_circuit','Actual msp','Actual msp_circuit','Actual ottp','Actual lt_sw_fuse_unit','Actual delivery_point',
                  'Actual bbc_ahd_','Actual dist__box'])
# 
    return fig
