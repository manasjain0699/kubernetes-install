import datetime
from functools import reduce
from pkg_resources import normalize_path
import streamlit as st
import pandas as pd
import altair as alt
import os
from PIL import Image
import matplotlib.pyplot as plt
import joblib
import streamlit.components.v1 as components
from sklearn.metrics import confusion_matrix,classification_report
import numpy as np
import seaborn as sns
import pickle
import dill
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,precision_score,f1_score
import seaborn as sns
import numpy as np
import shap
import datetime as dt
import streamlit.components.v1 as components
from .functions import eval_metrics,performance_matices,convert_df,predict,hierarchy_asset_affected,img_to_bytes,st_shap,mergefiles
from .transformations import *
from .utilities import *
import datetime

SCALE = alt.Scale(type='linear')
def chart_1(cmplt_file_df):
    temp = cmplt_file_df[['complaint_number','reg_date']]
    temp['reg_date'] = pd.to_datetime(temp['reg_date'])
    temp['reg_date_month'] = temp['reg_date'].dt.month
    temp['reg_date_year'] = temp['reg_date'].dt.year
    temp = pd.DataFrame(temp.groupby(['reg_date_year','reg_date_month'])['complaint_number'].count()).reset_index()
    c1 = alt.Chart(temp).properties(height=300).mark_line().encode(
        x=alt.X("reg_date_month:N", title="Registration Date"),
        y=alt.Y("complaint_number:Q", title="Complaints count", scale=SCALE),
        color=alt.Color('reg_date_year:N', title="Year",scale=alt.Scale(domain=[2019, 2020,2021],range=['LimeGreen', 'Coral','RebeccaPurple'])),
        tooltip=['reg_date_year','reg_date_month','complaint_number']
    ).interactive().configure_legend(orient="top")
    st.header("Numer of complaints in every year")
    st.altair_chart(c1,use_container_width=True)

def chart_2(cmplt_file_df):
    temp = cmplt_file_df[['complaint_number','account_class']]
    temp = pd.DataFrame(temp.groupby(['account_class'])['complaint_number'].count()).reset_index()
    c2 = alt.Chart(temp).properties(height=350,width=160).mark_bar().encode(
        x=alt.X("account_class:N", title="Account Class"),
        y=alt.Y("complaint_number:Q", title="Complaints count", scale=SCALE),
        color=alt.Color('account_class:N', title="Delay",scale=alt.Scale(domain=temp["account_class"].unique().tolist(),range=['LimeGreen', 'Coral','RebeccaPurple','yellow','black','red'])),
        tooltip=['account_class','complaint_number'],
        #column='posting_date_year:N'
    ).configure_mark(color="crimson").configure_axis(labelFontSize=10,titleFontSize=20,labelAngle=45).configure_legend(orient="top").interactive()
    st.header("Complaint Count in Account Class")
    st.altair_chart(c2,use_container_width=True) 

def chart_3(cmplt_hrchy):
    temp = cmplt_hrchy[['parent_complaint_number','parent_reg_date','flg']]
    temp['parent_reg_date'] = pd.to_datetime(temp['parent_reg_date'])
    temp['parent_reg_date_year'] = temp['parent_reg_date'].dt.year
    temp = pd.DataFrame(temp.groupby(['flg','parent_reg_date_year'])['parent_complaint_number'].count()).reset_index().sort_values('parent_complaint_number',ascending=False)
    c2 = alt.Chart(temp).properties(height=400,width=160).mark_bar().encode(
        x=alt.X("flg:N", title="Functional Location Group"),
        y=alt.Y("parent_complaint_number:Q", title="Complaint Count", scale=SCALE),
        color=alt.Color('parent_reg_date_year:N', title="Year",scale=alt.Scale(domain=[2019, 2020,2021],range=['LimeGreen', 'Coral','RebeccaPurple'])),
        tooltip=['flg','parent_reg_date_year','parent_complaint_number'],
        #column='posting_date_year:N'
    ).interactive()
    st.header("Complaints in FLG")
    st.altair_chart(c2,use_container_width=True)

def chart_4(cmplt_file_df):
    temp = cmplt_file_df[['complaint_number','reg_date','bp_classification']]
    temp['reg_date'] = pd.to_datetime(temp['reg_date'])
    temp['reg_date_year'] = temp['reg_date'].dt.year
    temp = pd.DataFrame(temp.groupby(['bp_classification','reg_date_year'])['complaint_number'].count()).reset_index().sort_values('complaint_number',ascending=False)
    c2 = alt.Chart(temp).properties(height=400,width=160).mark_bar().encode(
        x=alt.X("bp_classification:N", title="BP Classification"),
        y=alt.Y("complaint_number:Q", title="Complaint Count", scale=SCALE),
        color=alt.Color('reg_date_year:N', title="Year",scale=alt.Scale(domain=[2019, 2020,2021],range=['LimeGreen', 'Coral','RebeccaPurple'])),
        tooltip=['bp_classification','reg_date_year','complaint_number'],
        #column='posting_date_year:N'
    ).interactive()
    st.header("Complaint count for BP Classification")
    st.altair_chart(c2,use_container_width=True)







