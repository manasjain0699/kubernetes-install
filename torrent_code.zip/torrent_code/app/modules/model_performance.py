
import datetime
from functools import reduce
from pkg_resources import normalize_path
import streamlit as st
import pandas as pd
import altair as alt
import os
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib
import joblib
import streamlit.components.v1 as components
from sklearn.metrics import confusion_matrix,classification_report
import numpy as np
import seaborn as sns
import pickle
import dill
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,precision_score,f1_score
import seaborn as sns
import numpy as np
import shap
import datetime as dt
import streamlit.components.v1 as components
from .functions import eval_metrics,performance_matices,convert_df,predict,hierarchy_asset_affected,img_to_bytes,st_shap,mergefiles,create_bulk_cmplt_df,no_of_times_comlpt_for_bulk_customer
from .transformations import *
from .utilities import *
import datetime
import plotly.express as px
import lime
import lime.lime_tabular
import dill

pred_flag = False

def limefig(x):
    
    exp = explainer.explain_instance(x,model.predict_proba, top_labels=1)
    return components.html(exp.as_html(),height=400)

def feature_importance_chart(cmplt_file_df,hrcrhy_file_df,child_file_df,model,top_features_rfe):
    st.header("Model Performance")
    st.write("**Note** : Upload the data only when you have true/actual **result(functional location group)** available for the complaints ")
    
    sample_cmplt_df = cmplt_file_df.head(1000).copy()
     
    sample_child_df = child_file_df.head(1000).copy()

    
    st.write("**Sample complaint input file structure**")
    st.write(sample_cmplt_df.head())
    csv = convert_df(sample_cmplt_df.head(1000))
    st.download_button("DownloadSample",csv,"sample_parent_cmplt.csv","text/csv",key='download-csv')


    st.write("**Sample child complaint input file structure**")
    st.write(sample_child_df.head())
    csv = convert_df(sample_child_df.head(1000))
    st.download_button("DownloadSample",csv,"sample_child_cmplt.csv","text/csv",key='download-csv')

    st.header("Feature Importance Chart: ")
    feature_imp=pd.DataFrame(sorted(zip(model.feature_importances_,top_features_rfe)),columns=['Value','Feature'])
    fig = plt.figure(figsize=(20,10))
    sns.barplot(x="Value",y="Feature",data=feature_imp.sort_values(by="Value",ascending=False))
    plt.title("Feature Importance")
    plt.tight_layout()
    st.pyplot(fig)

def model_performance_chart(cmplt_hrchy,hrcrhy_file_df,model,label_encode,top_features_rfe):
    global pred_flag

    col1, col2, col3 = st.columns(3)

    with col1:
        cmplt_file_upload = st.file_uploader("Upload parent complaint csv file for predictions (file structure should be exactly like the sample file)", type=["csv"])

    

    with col2:
        child_file_upload = st.file_uploader("Upload child complaint csv file for predictions (file structure should be exactly like the sample file)", type=["csv"])    
    
    if cmplt_file_upload is None:
        st.error("Please upload parent complaint file")
    elif  child_file_upload is None:
        st.error("Please upload child complaint file")     

    elif cmplt_file_upload  and child_file_upload :
         
        up_prnt_hrchy_child =  create_bulk_cmplt_df(cmplt_file_upload,child_file_upload,hrcrhy_file_df)
        up_prnt_hrchy_child['flg'] = create_label(up_prnt_hrchy_child,hrcrhy_file_df)
        removed_recs = up_prnt_hrchy_child[up_prnt_hrchy_child['flg']=='not_in_hierarchy']
        up_prnt_hrchy_child = up_prnt_hrchy_child[up_prnt_hrchy_child['flg']!='not_in_hierarchy']
        
        if not removed_recs.empty:
            st.write("Removed the below records as their FLG does not match with any hierarchy level ")
            st.write(removed_recs)

        if "pred_flag" not in st.session_state:
            st.session_state['pred_flag']=False

        if not st.session_state['pred_flag']:   
            predictions = model.predict(up_prnt_hrchy_child[top_features_rfe].fillna(-1))
            batch_df_unencode = up_prnt_hrchy_child[['parent_business_partner','parent_complaint_number','child_partner_no','parent_reg_date_time','child_reg_date_time','child_registration_time']+top_features_rfe]
            batch_df_unencode['predicted_flg'] = predictions
            batch_df_unencode['actual_flg'] = up_prnt_hrchy_child['flg'].map(label_mapping)
            batch_df_unencode['predicted_flg_description'] = batch_df_unencode['predicted_flg'].map(lb_key_list)
            batch_df_unencode['actual_flg_description'] = up_prnt_hrchy_child['flg']
            (acc_score,recall,f1_scr,precision_scr) = eval_metrics(batch_df_unencode['actual_flg'],batch_df_unencode['predicted_flg'])
        
            if "acc_score" not in st.session_state:
                st.session_state["acc_score"] = acc_score
            if "recall" not in st.session_state:
                st.session_state["recall"] = recall
            if "f1_scr" not in st.session_state:
                st.session_state["f1_scr"] = f1_scr
            if "precision_scr" not in st.session_state:
                st.session_state["precision_scr"] = precision_scr 
            if "df" not in st.session_state:
                st.session_state["df"] = batch_df_unencode    
            pred_flag = True
        st.header("Prediction Results")
        st.write(st.session_state["df"])
        csv = convert_df(st.session_state["df"])
        st.download_button("Download the Result",csv,"results.csv","text/csv",key='download-csv')
        
        X = up_prnt_hrchy_child.drop("flg",axis=1)
        y = up_prnt_hrchy_child['flg'].map(label_mapping)
        X = X[top_features_rfe] 
        
                   
        st.header("Model Performance Metrics")
        st.write("- **Total records on which performance was tested:**",up_prnt_hrchy_child.shape[0])
        st.write("- **Total parent complaints for which performance was tested:**",len(up_prnt_hrchy_child['parent_complaint_number'].unique()))
        st.write("- **Accuracy:** ",st.session_state["acc_score"])
        #st.write("AUC_ROC: ",auc_roc)
        st.write("- **Recall:** ",st.session_state["recall"])
        st.write("- **F1 score:** ",st.session_state["f1_scr"])
        st.write("- **Precision score:** ",st.session_state["precision_scr"])
        
        complaint_number_list = st.session_state["df"]['parent_complaint_number'].unique().tolist()
        selected_cmplt = st.selectbox('Select the parent complaint number',complaint_number_list,key='complaint_number')
        if selected_cmplt:
            saved_df = st.session_state["df"]
            fig_df = saved_df[saved_df['parent_complaint_number']==selected_cmplt]
            index_list = saved_df[saved_df['parent_complaint_number']==selected_cmplt].index
            #fig_df['lime_component'] = fig_df[top_features_rfe].fillna(-1).apply(lambda x: limefig(x),axis=1)
            c1 = alt.Chart(fig_df).properties(height=500).mark_line(point=True,strokeWidth=4).encode(
                 x = alt.X("time_diff_btwn_child_parent_cmplt_mins:N",title="Arrival of child complaint minutes after parent complaint",axis=alt.Axis(grid=True)),
                 y = alt.Y('actual_flg_description:O',title='Functional location group',scale=alt.Scale(domain=list(label_mapping.keys())),axis=alt.Axis(grid=True)),
                 color=alt.value('Crimson'),
                 tooltip = ['parent_complaint_number','parent_reg_date_time','child_partner_no','parent_reg_date_time','child_reg_date_time','actual_flg_description','predicted_flg_description']
             )
            c2 = alt.Chart(fig_df).properties(height=500).mark_line(point=True).encode(
                 x = alt.X("time_diff_btwn_child_parent_cmplt_mins:N",title="Arrival of child complaint minutes after parent complaint",axis=alt.Axis(grid=True)),
                 y = alt.Y('predicted_flg_description:O',title='Functional location group',scale=alt.Scale(domain=list(label_mapping.keys())),axis=alt.Axis(grid=True)),
                 color=alt.value('Limegreen'),
                 tooltip = ['parent_complaint_number','parent_reg_date_time','child_partner_no','parent_reg_date_time','child_reg_date_time','actual_flg_description','predicted_flg_description']
                 #tooltip=["lime_component"]
             )
            st.altair_chart(c1+c2,use_container_width=True) 
            
            st.subheader("Model Explainability for every child complaint")
            for c,i in enumerate(index_list):
                st.write("**child complaint: **",c+1)
                
                limefig(saved_df[top_features_rfe].loc[i])
                st.markdown("--"*25)
