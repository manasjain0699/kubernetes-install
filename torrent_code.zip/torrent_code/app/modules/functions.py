import datetime
from functools import reduce
from pkg_resources import normalize_path
import streamlit as st
import pandas as pd
import altair as alt
import os
from PIL import Image
import matplotlib.pyplot as plt
import joblib
import streamlit.components.v1 as components
from sklearn.metrics import confusion_matrix,classification_report
import numpy as np
import seaborn as sns
import pickle
import dill
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,precision_score,f1_score
import seaborn as sns
import numpy as np
import shap
import datetime as dt
from .transformations import *
from .utilities import label_encode,hierachy_label_encode,top_features_rfe,feat_dict,hierarchy_cols,base_dir
import streamlit.components.v1 as components


def eval_metrics(actual,pred):
  
    acc_score = accuracy_score(actual, pred)
    print("accuracy: ",acc_score)
    recall = recall_score(actual, pred,average='weighted')
    print("recall: ",recall)
    f1_scr = f1_score(actual, pred,average='weighted')
    print("f1_scr: ",f1_scr)
    precision_scr = precision_score(actual, pred,average='weighted')
    print("precision_scr: ",precision_scr)
    return acc_score,recall,f1_scr,precision_scr


def performance_matices(model, X, y, order_hierarchy) :

    y_pred = model.predict(X)
    
    confusion_matrix_print = confusion_matrix(y, y_pred,labels=order_hierarchy) 
    group_counts = ["{0:0.0f}".format(value) for value in
    confusion_matrix_print.flatten()]
    group_percentages = ['{0:.2%}'.format(value) for value in
    confusion_matrix_print.flatten()/np.sum(confusion_matrix_print)]

 
    labels = [f"{v1}\n{v2}" for v1, v2 in zip(group_percentages,group_counts)]
    labels = np.asarray(labels).reshape(len(y.unique()),len(y.unique()))
# 
    fig, ax = plt.subplots(figsize=(20,20))
    sns.heatmap(confusion_matrix_print, annot=labels, fmt='', cmap='Blues',robust=True,
    annot_kws={'fontsize':'large','fontweight':'bold'}
    ,cbar=False,xticklabels=['Predicted dist__sub_station','Predicted dist_transformer','Predicted fsp','Predicted fsp_circuit','Predicted fsp_sub_circuit',
                             'Predicted dfsp','Predicted dfsp_circuit','Predicted dfsp_sub_circuit','Predicted msp','Predicted msp_circuit','Predicted ottp',
                             'Predicted lt_sw_fuse_unit','Predicted delivery_point','Predicted bbc_ahd_','Predicted dist__box']
    ,yticklabels=['Actual dist__sub_station','Actual dist_transformer','Actual fsp','Actual fsp_circuit','Actual fsp_sub_circuit','Actual dfsp',
                  'Actual dfsp_circuit','Actual dfsp_sub_circuit','Actual msp','Actual msp_circuit','Actual ottp','Actual lt_sw_fuse_unit','Actual delivery_point',
                  'Actual bbc_ahd_','Actual dist__box'])
    return fig 

def convert_df(df):
    return df.to_csv().encode('utf-8')
    
def predict(model, input_df):
    predictions = model.predict(input_df)[0]
    prediction_prob = model.predict_proba(input_df)
    return predictions,prediction_prob

def hierarchy_asset_affected(temp_cmp, column_name):
    new_column = column_name+"_past_affected"
    temp_cmp['reg_date_time'] = temp_cmp['reg_date'] + " " + temp_cmp['reg__time']
    temp_cmp['reg_date_time'] = pd.to_datetime(temp_cmp['reg_date_time'],format="%d-%m-%Y %H:%M:%S")
    temp_join = pd.merge(temp_cmp[['reg_date_time','complaint_number',column_name]],temp_cmp,how='left',
                         left_on=column_name,right_on='affected_func__location')[['reg_date_time_x','complaint_number_x',column_name+"_x",'reg_date_time_y',
                                                                                      column_name+'_y','affected_func__location']]
    temp_join[new_column] = 1
    temp_reduce = temp_join[temp_join['reg_date_time_x']>temp_join['reg_date_time_y']].groupby(['reg_date_time_x',column_name+"_x"])[new_column].sum()
    
    temp_cmp_df = pd.merge(temp_cmp,temp_reduce,how='left',left_on=['reg_date_time',column_name],right_on=['reg_date_time_x',column_name+'_x'])
    
    temp_cmp_df[new_column] = temp_cmp_df[new_column].fillna(0)
    
    return temp_cmp_df

def img_to_bytes(img_path):
    import base64
    encoded = base64.b64encode(open(img_path, "rb").read()).decode()
    return encoded

def st_shap(plot,height=None):
    shap_html = f"<head>{shap.getjs()}</head><body>{plot.html()}</body>"
    components.html(shap_html,height=height)

  

def mergefiles(x,y,left,right,key):
        return x.merge(y,left_on=left,right_on=right,how=key)   

def no_of_times_comlpt_for_bulk_customer(x,col,col_suffix):

    if "feat_dict" not in st.session_state:
        st.session_state["feat_dict"] = feat_dict
    if x =='not-connected':
        return -1
    if x in st.session_state["feat_dict"][col+col_suffix]:
        val = st.session_state["feat_dict"][col+col_suffix][x]
        if col_suffix in ['_no_of_times_comlpt_raised_for_asset','no_of_complaints_for_bp_past']:
                st.session_state["feat_dict"][col+col_suffix][x] = val+1
    else:
        val = 0
        st.session_state["feat_dict"][col+col_suffix][x] = val+1
    return val        

def create_bulk_cmplt_df(cmplt_file_upload,child_file_upload,hrcrhy_file_df):
        uploaded_parent_cmplt = pd.read_csv(cmplt_file_upload) 
   
        uploaded_child = pd.read_csv(child_file_upload)

        #--------rename columns-------------------------
        
        uploaded_parent_cmplt.columns = rename_columns(uploaded_parent_cmplt,prefix="parent_")
       

        uploaded_child.columns = rename_columns(uploaded_child,prefix="child_")
        
        ##----------taking useful columns from parent file--------------
        #
        #uploaded_parent_cmplt=uploaded_parent_cmplt[parent_columns]
        
        try:
            uploaded_child['child_parent_complaint'] = uploaded_child['child_parent_complaint'].astype(int)
            uploaded_parent_cmplt['parent_complaint_number'] = uploaded_parent_cmplt['parent_complaint_number'].astype(int)
        except:
            print("Complaint Number column must not contain any special character. It must be strictly integers")    
        #---------------- First merge child hrchy file---------------------
        #---------- then join with parent complaint number-----------------
        
    
        #up_prnt_hrchy = mergefiles(uploaded_parent_cmplt,hrcrhy_file_df,'parent_business_partner','hrcrhy_business_partner','inner')

        uploaded_child = mergefiles(uploaded_child,hrcrhy_file_df,'child_partner_no','hrcrhy_business_partner','inner')

        up_prnt_hrchy_child = mergefiles(uploaded_parent_cmplt,uploaded_child,'parent_complaint_number','child_parent_complaint','inner')

        up_prnt_hrchy_child_unencode = up_prnt_hrchy_child.copy()

        #---------------fill reg date time--------------
        up_prnt_hrchy_child['parent_reg__time'] = fill_parent_reg__time(up_prnt_hrchy_child)

        #---------------fill parent category----------------
        up_prnt_hrchy_child['parent_rate_category'] = fill_parent_rate_category(up_prnt_hrchy_child)

          #----------------fill parent area---------------------
        up_prnt_hrchy_child['parent_area'] = fill_parent_area(up_prnt_hrchy_child) 

        #--------------- fill parent mru-----------------------
        up_prnt_hrchy_child['parent_mru'] = fill_parent_mru(up_prnt_hrchy_child)

        #--------------- format reg date time-----------------
        up_prnt_hrchy_child['parent_reg_date_time'] = format_parent_reg_date(up_prnt_hrchy_child)

        #---------------------- format child date---------------------------------
        up_prnt_hrchy_child['child_reg_date_time'] = format_child_reg_date(up_prnt_hrchy_child)
        
        #-------------------create date time features---------------------------------

        up_prnt_hrchy_child  = date_time_features(up_prnt_hrchy_child,'parent_reg_date_time')

        up_prnt_hrchy_child  = date_time_features(up_prnt_hrchy_child,'child_reg_date_time')



        #--------------------------hierarchy features-----------------------------------


        up_prnt_hrchy_child['parent_reg__time'] = fill_parent_reg__time(up_prnt_hrchy_child)
        up_prnt_hrchy_child['parent_rate_category'] = fill_parent_rate_category(up_prnt_hrchy_child)
        up_prnt_hrchy_child['parent_area'] = fill_parent_area(up_prnt_hrchy_child[['parent_area']])
        up_prnt_hrchy_child['parent_mru'] = fill_parent_mru(up_prnt_hrchy_child[['parent_mru']])
        up_prnt_hrchy_child['child_mru'] = fill_child_mru(up_prnt_hrchy_child[['child_mru']])
        up_prnt_hrchy_child['parent_reg_date_time'] = format_parent_reg_date(up_prnt_hrchy_child)
        up_prnt_hrchy_child['child_reg_date_time'] = format_child_reg_date(up_prnt_hrchy_child)
        
        #-----------------------encoding features---------------------------------------
        
        encode_features = label_encode.cols
        
        hrchy_en_features = hierachy_label_encode.cols
       
        up_prnt_hrchy_child.sort_values('child_reg_date_time',inplace=True)
        
        for col in hierarchy_cols:
            up_prnt_hrchy_child[col+'_no_of_times_comlpt_raised_for_asset'] = up_prnt_hrchy_child[col].apply(lambda x: no_of_times_comlpt_for_bulk_customer(x,col,'_no_of_times_comlpt_raised_for_asset'))

        for col in hierarchy_cols:
            up_prnt_hrchy_child[col+'_noof_times_affected_in_past'] = up_prnt_hrchy_child[col].apply(lambda x: no_of_times_comlpt_for_bulk_customer(x,col,'_noof_times_affected_in_past')) 

        for col in hierarchy_cols:
            up_prnt_hrchy_child[col+'_noof_days_before_affected_in_past'] = up_prnt_hrchy_child[col].apply(lambda x: no_of_times_comlpt_for_bulk_customer(x,col,'_noof_days_before_affected_in_past'))       
   
        up_prnt_hrchy_child[encode_features] = label_encoding_transfrom(up_prnt_hrchy_child[encode_features],base_dir+"label_encode.joblib")
        up_prnt_hrchy_child[hrchy_en_features] = label_encoding_transfrom(up_prnt_hrchy_child[hrchy_en_features],base_dir+"hrcrhy_label_encode.joblib")
        
        #--------------------check if parent is ht customer or not----------------
        up_prnt_hrchy_child['is_parent_ht_customer']  =  is_parent_ht_customer(up_prnt_hrchy_child)

        # ------------------------past complaints of child bp----------------------------
        
        up_prnt_hrchy_child['no_of_complaints_for_bp_past'] = up_prnt_hrchy_child['child_partner_no'].apply(lambda x: no_of_times_comlpt_for_bulk_customer(x,'no_of_complaints_for_bp_past',''))

        #--------------------time difference between child and parent-------------------

        up_prnt_hrchy_child['time_diff_btwn_child_parent_cmplt_mins'] =  time_diff_btwn_child_parent_cmplt(up_prnt_hrchy_child)
         
        #------------------number of child complaint in past---------------------------

        up_prnt_hrchy_child['no_of_past_child_cmplt'] = no_of_past_child_cmplt(up_prnt_hrchy_child)

        #-------------------- is child vip or not--------------------------------------
        up_prnt_hrchy_child['child_vip_flag'] = child_vip_flag(up_prnt_hrchy_child)        

        return  up_prnt_hrchy_child
