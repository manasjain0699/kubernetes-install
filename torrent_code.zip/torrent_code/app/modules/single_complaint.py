import datetime
from functools import reduce
from pkg_resources import normalize_path
import streamlit as st
import pandas as pd
import altair as alt
import os
from PIL import Image
import matplotlib.pyplot as plt
import joblib
import streamlit.components.v1 as components
from sklearn.metrics import confusion_matrix,classification_report
import numpy as np
import seaborn as sns
import pickle
import dill
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score,classification_report,confusion_matrix,accuracy_score,recall_score,precision_score,f1_score
import seaborn as sns
import numpy as np
import shap
import datetime as dt
import streamlit.components.v1 as components
from .functions import eval_metrics,performance_matices,convert_df,predict,hierarchy_asset_affected,img_to_bytes,st_shap,mergefiles
from .transformations import *
from .utilities import *
import datetime

empty_flag = True

def single_complaint_chart(cmplt_hrchy,cmplt_file_df,hrcrhy_file_df,model,label_encode,top_features_rfe):
    global empty_flag
    input_df = pd.DataFrame()

    st.header("Register child complaint for selected Parent Complaint ")
    prnt_cmpt_n = st.text_input("Enter Parent Complaint Number:")
    child_bp =    st.text_input("Enter child complaint Business Partner:")
    location = st.text_input("Location of child bp eg.D-AZ-01","")
    mru = st.text_input("MRU of child bp eg. OZ190703","")
    area = st.text_input("area of child bp eg. Karnavatinagar","")
    child_reg_date = st.text_input("Select child complaint date: format yyyy-mm-dd")
    child_reg_time = st.text_input("Select child complaint time: HH:MM:SS in 24 hour format") 
    vip =  st.selectbox("Is child BP a VIP client:",['yes','no'])

    if not prnt_cmpt_n :
        st.error("Please enter parent complain number")
    elif not  child_bp:
        st.error("Please enter child bp number")
    elif not  location:
        st.error("Please enter child bp's location")
    elif not mru:
        st.error("Please enter child bp's mru")
    elif not  area:
        st.error("Please enter child bp's area")
    elif not child_reg_date:
        st.error("Please enter child complaint date")
    elif not child_reg_time:
        st.error("Please enter child complaint time")        

    else:                 
        input_df['parent_complaint_number'] = pd.Series(int(prnt_cmpt_n))
        input_df['child_business_partner'] = pd.Series(int(child_bp))

        input_df['child_location'] = pd.Series(location)
        input_df['child_mru'] = pd.Series(mru)
        input_df['child_area'] = pd.Series(area)
        child_reg_date_time = child_reg_date+" "+child_reg_time
        cmbn_date_time = datetime.datetime.fromisoformat(child_reg_date_time)


        input_df['child_reg_date_time'] =  pd.to_datetime(pd.Series(cmbn_date_time))
        input_df['child_vip_flag'] = pd.Series(vip)
        input_df['child_vip_flag'] = np.where(input_df['child_vip_flag'].values[0]=="yes",1,0)
    
    
        ##----------------select the details of parent against which complaint has been registered-------------------  

        selected_parent_df = cmplt_file_df[cmplt_file_df['complaint_number'] == input_df['parent_complaint_number'].values[0]]
        selected_parent_df.columns = rename_columns(selected_parent_df,prefix="parent_")
        selected_parent_df['parent_reg_date_time'] = format_parent_reg_date(selected_parent_df)
        
        ##----------------select the details of hrchy for child bp who registered the complaint-------------------
        selected_hrcrhy_df =  hrcrhy_file_df[hrcrhy_file_df['hrcrhy_business_partner']==input_df['child_business_partner'].values[0]]
        

        #---------------create date features from parent-------------------------
        input_df = date_time_features(input_df,'child_reg_date_time') 
        selected_parent_df = date_time_features(selected_parent_df,'parent_reg_date_time')

        #-----------------------finding parent and hierarchy features that are selected from feature selection method---------
        parent_hrchy_related_feats = [x for x in top_features_rfe if 'parent_' in x[:7] ]
        parent_hrchy_related_feats.extend([x for x in top_features_rfe if 'hrcrhy_' in x[:7] ])

        parent_hrchy_related_feats.append('parent_reg_date_time')
        
        #-----------------no_of child_cmplt feature in past fetch prev value and  added one-------------------
        cmplt_impacted_cols = list(filter(lambda x: 'no_of_times_comlpt' in x, top_features_rfe)) 

        #-----------------Checking if the previous state of past child complaint is present in file or not----------
        ##  here we are trying to save the states whenever a child complaint is raise against a parent complaint
        ## if present then just fetch details from lastest entry of a specific parent complaint from the dataframe
        #------------------------------------------------------------------------------------------------------------

        read_prev_state = pd.read_csv("saved_state_of_parent_with_child.csv")

        #--------------merge child parent hieracrchy dataframe------------------ 
        input_df = mergefiles(input_df,selected_parent_df,'parent_complaint_number','parent_complaint_number','inner') 
        input_df = mergefiles(input_df,selected_hrcrhy_df,'child_business_partner','hrcrhy_business_partner','inner')
        input_cols = ['parent_complaint_number','child_business_partner','child_reg_date_time','child_location','child_area','child_mru']

        if not read_prev_state.empty:
            read_prev_state = read_prev_state[read_prev_state['parent_complaint_number']==input_df['parent_complaint_number'].values[0]]
            st.write("past complaints for the specified parent complaint")
            
            st.write(read_prev_state[input_cols+['prediction']])
            read_prev_state.sort_values("child_reg_date_time",inplace=True)
            last_row = read_prev_state.loc[read_prev_state.index[-1]]
            if 'no_of_past_child_cmplt' in top_features_rfe:
                input_df['no_of_past_child_cmplt'] = last_row['no_of_past_child_cmplt']+1
                
        else:
            if 'no_of_past_child_cmplt' in top_features_rfe:
                input_df['no_of_past_child_cmplt'] = 1
               
        #--------------------map the noof features dictionary to get the entries----------

        hr_sel_feat = list(filter(lambda x: 'noof' in x or '_no_of' in x, top_features_rfe))

        for col in hr_sel_feat:
            if '_noof' in col:
                ori_col = col.split('_noof')[0]
            else:
                ori_col = col.split('_no_of')[0]
            if input_df[ori_col].values[0] in feat_dict[col].keys():
                input_df[col] = input_df[ori_col].map(feat_dict[col]) 
            else:
                feat_dict[col][input_df[ori_col].values[0]] =0
                input_df[col]=0
            if col in cmplt_impacted_cols:
                feat_dict[col][input_df[ori_col].values[0]] = input_df[col].values[0]+1
        
        #----------------only calculate some fatures if they have appeared in selected features list---------------------------        
                   
        if 'is_parent_ht_customer' in  top_features_rfe:
            input_df['is_parent_ht_customer']  =  input_df(up_prnt_hrchy_child)   
            
        if 'no_of_complaints_for_bp_past' in top_features_rfe:
            input_df['no_of_complaints_for_bp_past'] = input_df['child_partner_no'].map(feat_dict['no_of_complaints_for_bp_past'])
            feat_dict['no_of_complaints_for_bp_past']['child_partner_no'] = input_df['no_of_complaints_for_bp_past'].values[0]+1

        #------------------------encoding for hrcrhy and parent features-------------
        encode_features = label_encode.cols
        sel_enc_feat = list(filter(lambda x: x in encode_features, top_features_rfe))
        for col in sel_enc_feat:
            input_df[col] = input_df[col].map(dict(label_encode.mapping[label_encode.cols.index(col)]['mapping']))


        hrchy_en_features = hierachy_label_encode.cols
        sel_hr_enc_feat = list(filter(lambda x: x in hrchy_en_features, top_features_rfe))
        for col in sel_hr_enc_feat:
            input_df[col] = input_df[col].map(dict(hierachy_label_encode.mapping[hierachy_label_encode.cols.index(col)]['mapping']))      
        
        


        if 'time_diff_btwn_child_parent_cmplt_mins' in top_features_rfe:    
            input_df['time_diff_btwn_child_parent_cmplt_mins'] = time_diff_btwn_child_parent_cmplt(input_df)   

        if 'median_affected_bp_past' in top_features_rfe:
            input_df['median_affected_bp_past'] = input_df['parent_business_partner'].map(feat_dict['median_affected_bp_past'])
        if 'average_affected_bp' in top_features_rfe:
            input_df['average_affected_bp'] = input_df['parent_business_partner'].map(feat_dict['average_affected_bp'])

        #----------------------------------prediction panel----------------------------------------------------------------
        output=""
        output_prob=""
        if st.button("Predict"):
            output,output_prob = predict(model=model, input_df=input_df[top_features_rfe].fillna(-1))
    
            input_df['prediction'] = output
            flg =""
            for key,value in label_mapping.items():
                if value==output:
                    flg=key
            
            st.success("There are chances that fault will occur in **{}** group".format(flg))
            input_df['prediction'] = flg    
            if empty_flag:
                
                input_df.to_csv("saved_state_of_parent_with_child.csv",index=False)
                empty_flag = False
            else:
                input_df.to_csv("saved_state_of_parent_with_child.csv",mode='a',index=False,header=False)
                
    #----------------------Shapley feature explaination----------------------------------------
            st.subheader("Model explainability")
            with st.spinner("Calculating"):
                exp = explainer.explain_instance(input_df[top_features_rfe].fillna(-1).iloc[-1],model.predict_proba, top_labels=1)
                components.html(exp.as_html(),height=800)

